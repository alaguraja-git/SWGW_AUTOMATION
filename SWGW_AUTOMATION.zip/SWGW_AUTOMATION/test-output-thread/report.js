$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "a411f80a-518c-434b-ae49-1a5776af48c1",
    "feature": "Sucessfull Downloader Feature",
    "scenario": "Sucessfull Downloader Scenario",
    "start": 1668753551240,
    "group": 1,
    "content": "",
    "tags": "@sucessfulldownloader,",
    "end": 1668753763336,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});