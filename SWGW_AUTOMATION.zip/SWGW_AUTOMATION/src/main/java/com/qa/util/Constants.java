package com.qa.util;

public class Constants {
	
	public static int IMPLICIT_WAIT = 20;	
	public static int DOWNLOADER_PAGEWAIt = 30;
	
	
	public long timerInSeconds = 2400;
}
